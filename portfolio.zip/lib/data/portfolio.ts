/**
 * All portfolio content lives here.
 * Edit this file to update the site; components never hold copy.
 */

export type Link = { label: string; href: string };

export type Project = {
  title: string;
  description: string;
  stack: string[];
  year: string;
  repo?: string;
  demo?: string;
  /** Featured projects span the full width of the grid. */
  featured?: boolean;
};

export type SkillGroup = { label: string; items: string[] };

export type Job = {
  role: string;
  company: string;
  period: string;
  points: string[];
  stack?: string[];
};

export type Degree = {
  degree: string;
  school: string;
  period: string;
  note?: string;
};

export type Certificate = {
  name: string;
  issuer: string;
  year: string;
  href?: string;
};

export const profile = {
  name: "Your Name",
  role: "Software developer",
  /** Short line shown above the name. Set to "" to hide it. */
  status: "open to new roles",
  /** The one sentence a visitor should remember. */
  tagline: "I build backend systems and the web apps on top of them.",
  summary:
    "I care about small, readable codebases and software that is easy to operate. I like taking a vague problem and turning it into something people actually use.",
  email: "you@example.com",
  /** Path to a PDF in /public, e.g. "/resume.pdf". Leave undefined to hide the button. */
  resumeHref: undefined as string | undefined,
  links: [
    { label: "github", href: "https://github.com/your-username" },
    { label: "linkedin", href: "https://linkedin.com/in/your-username" },
  ] satisfies Link[],
  /** Quick facts shown under the hero. */
  facts: [
    { label: "currently", value: "Software Engineer at Company name" },
    { label: "focus", value: "Backend, APIs, developer tooling" },
    { label: "location", value: "City, Country" },
  ],
};

/** Order here controls the order of the header navigation. */
export const navigation: Link[] = [
  { label: "projects", href: "#projects" },
  { label: "experience", href: "#experience" },
  { label: "skills", href: "#skills" },
  { label: "education", href: "#education" },
  { label: "certifications", href: "#certifications" },
];

/** Section headings and the one-line intro under each. */
export const sections = {
  projects: { title: "projects", intro: "Things I have built and shipped." },
  experience: { title: "experience", intro: "Where I have worked." },
  skills: { title: "skills", intro: "What I use day to day." },
  education: { title: "education", intro: "Where I studied." },
  certifications: { title: "certifications", intro: "Credentials I have earned." },
};

export const projects: Project[] = [
  {
    title: "Project one",
    description:
      "A short sentence on what it does and the problem it solves. Add one measurable result if you have it, like users, latency or time saved.",
    stack: ["TypeScript", "Next.js", "PostgreSQL"],
    year: "2026",
    repo: "https://github.com/your-username/project-one",
    demo: "https://example.com",
    featured: true,
  },
  {
    title: "Project two",
    description:
      "Describe your part in it and what was technically interesting about it.",
    stack: ["Go", "gRPC", "Redis"],
    year: "2025",
    repo: "https://github.com/your-username/project-two",
  },
  {
    title: "Project three",
    description:
      "Keep each description to two lines and link to the code or a live demo.",
    stack: ["Python", "FastAPI", "Docker"],
    year: "2024",
    repo: "https://github.com/your-username/project-three",
  },
];

export const experience: Job[] = [
  {
    role: "Software Engineer",
    company: "Company name",
    period: "2024 - present",
    points: [
      "Built and shipped X, which reduced Y by Z%.",
      "Owned the migration of A to B across N services.",
    ],
    stack: ["TypeScript", "Node.js", "PostgreSQL"],
  },
  {
    role: "Junior Software Engineer",
    company: "Previous company",
    period: "2022 - 2024",
    points: [
      "Developed REST APIs consumed by web and mobile clients.",
      "Improved test coverage from X% to Y% on the core module.",
    ],
    stack: ["Python", "FastAPI"],
  },
];

export const skills: SkillGroup[] = [
  { label: "languages", items: ["TypeScript", "JavaScript", "Python", "Go", "SQL"] },
  { label: "frontend", items: ["React", "Next.js", "Tailwind CSS"] },
  { label: "backend", items: ["Node.js", "FastAPI", "PostgreSQL", "Redis"] },
  { label: "tooling", items: ["Git", "Docker", "Linux", "GitHub Actions"] },
];

export const education: Degree[] = [
  {
    degree: "B.Sc. in Computer Science",
    school: "University name",
    period: "2018 - 2022",
    note: "Thesis or focus area, if relevant.",
  },
];

export const certifications: Certificate[] = [
  {
    name: "Certification name",
    issuer: "Issuing organization",
    year: "2025",
    href: "https://example.com/credential",
  },
  {
    name: "Another certification",
    issuer: "Issuing organization",
    year: "2024",
  },
];